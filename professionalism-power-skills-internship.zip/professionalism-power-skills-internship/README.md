# Professionalism & Power Skills Job Simulation — Internship Submission

**Student:** Gaurav Mishra  
**Roll Number:** 25SCS1003000831  
**Programme:** B.Tech CSE  
**Batch:** 2025-2029  
**Institution:** IILM University, Greater Noida, U.P.

## Project
**Professional Workplace Communication and Team Problem-Solving Simulation**

This repository contains the internship/simulation submission prepared from the verified Forage certificate. The certificate records practical tasks in **first impressions and communication** and **teamwork and problem solving**.

## Repository Contents

- `Internship Report/` — Final internship report in DOCX format
- `Presentation/` — Final presentation in PPTX format
- `Certificate/` — Certificate of Completion
- `Assets/` — IILM crest and project visuals

## Verified Activity

**Program:** Professionalism & Power Skills Job Simulation  
**Platform:** Forage  
**Certificate date:** September 9, 2026

## Skills Covered

- First impressions and communication
- Teamwork
- Problem solving
- Professional workplace communication
- Reflection and continuous improvement

## Note

The project is presented as an academic representation of the verified job-simulation activities. No unverified employer, live deployment, or technical internship claims are added beyond the certificate-supported scope.
